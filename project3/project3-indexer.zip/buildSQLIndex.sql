CREATE TABLE ItemLocation
(
ItemID VARCHAR(500) NOT NULL,
LocGPS POINT NOT NULL, SPATIAL INDEX(LocGPS)
)ENGINE=MyISAM;

INSERT INTO ItemLocation(ItemID,LocGPS)
(
  SELECT ItemID, POINT(Seller_Latitude,Seller_Longitude)
  FROM Item
  -- WHERE Seller_Latitude <> 'NULL' AND Seller_Longitude <> 'NULL'
  WHERE Seller_Latitude IS NOT NULL AND Seller_Longitude IS NOT NULL
);