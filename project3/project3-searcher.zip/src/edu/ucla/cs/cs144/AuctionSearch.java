package edu.ucla.cs.cs144;

import java.io.*;
import java.text.*;
import java.util.*;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.Timestamp;


import org.apache.lucene.document.Document;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.Version;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.StringField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.document.DoubleField;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;

import java.text.SimpleDateFormat;

import edu.ucla.cs.cs144.DbManager;
import edu.ucla.cs.cs144.SearchRegion;
import edu.ucla.cs.cs144.SearchResult;

public class AuctionSearch implements IAuctionSearch {

	/* 
         * You will probably have to use JDBC to access MySQL data
         * Lucene IndexSearcher class to lookup Lucene index.
         * Read the corresponding tutorial to learn about how to use these.
         *
	 * You may create helper functions or classes to simplify writing these
	 * methods. Make sure that your helper functions are not public,
         * so that they are not exposed to outside of this class.
         *
         * Any new classes that you create should be part of
         * edu.ucla.cs.cs144 package and their source files should be
         * placed at src/edu/ucla/cs/cs144.
         *
         */
	
	public SearchResult[] basicSearch(String query, int numResultsToSkip, int numResultsToReturn) 
	{
		// TODO: Your code here!
		SearchResult result[]=null;
			try {

			        System.out.println("performSearch");
			        
			        String filePath = "/var/lib/lucene/index_ItemAndCategory";
			        String searchField = "Content";		
			        SearchEngine se = new SearchEngine(filePath,searchField);
			        String q = query;
			        TopDocs topDocs = se.performSearch(q,se.performSearch(q,1).totalHits);
	
			        //System.out.println("Results found: " + topDocs.totalHits);
			        
			        ScoreDoc[] hits = topDocs.scoreDocs;
			        //System.out.println("hits length: "+hits.length);
			        if (numResultsToSkip>=hits.length) return new SearchResult[0];
					int size = numResultsToSkip+numResultsToReturn>hits.length?hits.length-numResultsToSkip:numResultsToReturn;				
					result = new SearchResult[size];

			        int count=numResultsToSkip;
			        for (int i = 0; i < result.length; i++) 
			        {			        	
			            Document doc = se.getDocument(hits[count].doc);
			            String ItemID=doc.get("ItemID");
			            String Name = doc.get("Name");
			            //String Description = doc.get("Description");
			            result[i]=new SearchResult(ItemID, Name);
			            count++;
			        }
			        System.out.println("performSearch done");
			      } 
			      catch (Exception e) 
				  {
			        System.out.println("Exception caught.\n");
			      }
			    
		return result;
	}

	public SearchResult[] spatialSearch(String query, SearchRegion region,int numResultsToSkip, int numResultsToReturn) 
	//public void spatialSearch(String query,SearchRegion region)
	{
		// TODO: Your code here!
        Connection conn = null;
        // Add your code below 
               	
        SearchResult finalResults[]=null; 
       try
       {
           // create a connection to the database to retrieve Items from MySQL
            conn = DbManager.getConnection(true);
           
			Statement stmt = conn.createStatement();
			String setPolygon = "SET @poly = 'Polygon((" +
			region.getLx() + " " + region.getLy() + ", " +
			region.getLx() + " " + region.getRy() + ", " +
			region.getRx() + " " + region.getRy() + ", " +
			region.getRx() + " " + region.getLy() + ", " +
			region.getLx() + " " + region.getLy() +
				"))'";
			stmt.executeQuery(setPolygon);
			String sqlQuery = "SELECT ItemID, X(LocGPS), Y(LocGPS)" +
							  "FROM ItemLocation " +
						      "WHERE MBRContains(GeomFromText(@poly), LocGPS)";
			ResultSet RS_ItemLocation = stmt.executeQuery(sqlQuery);
      
			HashSet<String> hashSet = new HashSet<String>();
			
	        RS_ItemLocation.first();
	        RS_ItemLocation.previous();
	        while(RS_ItemLocation.next())
	        {
	        	
	        	String tmpItemID = RS_ItemLocation.getString("ItemID");
	        	hashSet.add(tmpItemID);

	           
	        }
	        
            // Recall the function basicSearch to return query matchin results.
	        String filePath = "/var/lib/lucene/index_ItemAndCategory";
	        String searchField = "Content";
	        SearchEngine se = new SearchEngine(filePath,searchField);
	        String q = query;
	        int size=se.performSearch(q,1).totalHits;
	       	        
            SearchResult results[]=basicSearch(query, 0,size);


          
            // start mapping
            ArrayList<SearchResult> finalResultsList = new ArrayList<SearchResult>();
    		for(SearchResult result : results) 
    		{
	        	if (hashSet.contains(result.getItemId()))
	        	finalResultsList.add(result);
    		}
    		
            //System.out.println("finalResultsList size:"+finalResultsList.size());
            if (numResultsToSkip>=finalResultsList.size()) return new SearchResult[0];
            int finalResults_Size = numResultsToSkip+numResultsToReturn>finalResultsList.size() ? finalResultsList.size()-numResultsToSkip : numResultsToReturn;
            
            finalResults = new SearchResult[finalResults_Size];
            int count=numResultsToSkip;
            for (int i=0;i<finalResults_Size;i++)
            {
            	finalResults[i]=finalResultsList.get(count);
            	count++;
            }
            
            
            
            //PS.close();
            stmt.close();
    	    conn.close();
    	    //indexWriter.close();
       }
       catch (Exception ex)
       {
           System.out.println("@debug: "+ex);
       }
		return finalResults;
      
	}

    
	public String getXMLDataForItemId(String itemId) 
	{
		// TODO: Your code here!
		Connection conn = null;
		String result = "<Item ItemID=\"" + itemId + "\">\n";
		
        
        
		try
	       {
	           // create a connection to the database to retrieve Items from MySQL
	            conn = DbManager.getConnection(true);
	            Statement stmt = conn.createStatement();
	            String query="SELECT * FROM Item WHERE ItemID="+itemId;
	            ResultSet RS_Item=stmt.executeQuery(query);
	            //if (RS_Item==null) return null;
	            if (!RS_Item.next())  return "";
	            RS_Item.first();
	            RS_Item.previous();
	            while(RS_Item.next())//Can be changed to RS_Item.first();
	            {
	            	
	            	result += "  <Name>" + getStringAfterEscape(RS_Item.getString("Name") )+ "</Name>\n";
	            	result += getXMLCategory(itemId);
	            	double Currently = RS_Item.getDouble("Currently");
	            	result += getXMLCurrently(Currently);
	            	double Buy_Price = RS_Item.getDouble("Buy_Price");
	            	result += getXMLBuyPrice(Buy_Price);
	            	double First_Bid = RS_Item.getDouble("First_Bid");
	            	result += getXMLFirstBid(First_Bid);
	            	int Number_of_Bids = RS_Item.getInt("Number_of_Bids");
	            	result += getXMLNumberOfBids(Number_of_Bids);
	            	result += getXMLBids(itemId,Number_of_Bids);
	            	result += getXMLSellerLocation(itemId);
	            	result += "  <Country>" + getStringAfterEscape(RS_Item.getString("Seller_Country")) + "</Country>\n";
	            	String Started=RS_Item.getString("Started");	            	
	            	result += "  <Started>"+ getXMLDate(Started) + "</Started>\n";
	            	String Ends=RS_Item.getString("Ends");
					result += "  <Ends>"+ getXMLDate(Ends) + "</Ends>\n";
					result += getXMLSeller(RS_Item.getString("Seller_UserID"));
					//result += "<Description>" + getStringAfterEscape(RS_Item.getString("Description")) + "</Description>\n";

					if (RS_Item.getString("Description")==null) result += "  <Description />\n";
					else result += "  <Description>" + getStringAfterEscape(RS_Item.getString("Description")) + "</Description>\n";
	            }
	            conn.close();
	       }
		catch (Exception ex) 
		  {
				System.out.println(ex);
		  }
		result += "</Item>";
		/*
		try
		{
			String f1="getXMLDataForItemId.txt";
			BufferedWriter out1=new BufferedWriter(new FileWriter(f1,false)); 
			out1.write(result);
			
			out1.flush();
			out1.close();
		}
		catch (IOException ex)
		{
			System.out.println(ex);
		}
		*/
		return result;
	}

	public String getXMLSeller(String Seller_UserID) 
	{
		Connection conn = null;
		String result="";
		try
		{
			conn = DbManager.getConnection(true);
			Statement stmt = conn.createStatement();
			String query = "SELECT * FROM Seller WHERE Seller_UserID = '" + Seller_UserID+"' ";
			ResultSet RS_Seller = stmt.executeQuery(query);
			while(RS_Seller.next())
			{
				result += "  <Seller";
				result += " Rating=\"" + RS_Seller.getInt("Seller_Rating")+ "\"";
				result += " UserID=\"" + getStringAfterEscape(Seller_UserID) + "\"";
				result += " />\n";
			}
		}
		catch (Exception ex) 
		{
			System.out.println(ex);
		}
		return result;
	}
	public String getXMLSellerLocation(String itemId) 
	{
		Connection conn = null;
		String result = "";
		try 
		{
			conn = DbManager.getConnection(true);
			Statement stmt = conn.createStatement();
			String query = "SELECT * FROM Item WHERE ItemID = " + itemId;
			ResultSet RS_Item = stmt.executeQuery(query);
			while (RS_Item.next()) //can be changed to RS_Item.first();
			{
				result += "  <Location";
				if (RS_Item.getString("Seller_Latitude") != null) 
				{
					result += " Latitude=\"" + RS_Item.getString("Seller_Latitude") + "\"";
				}
				if (RS_Item.getString("Seller_Longitude") != null) 
				{
					result += " Longitude=\"" + RS_Item.getString("Seller_Longitude") + "\"";
				}
				result += ">" + getStringAfterEscape(RS_Item.getString("Seller_Location")) + "</Location>\n";
			}		
			conn.close();
		} 
		catch (Exception ex) 
		{
			System.out.println(ex);
		}
		return result;
	}
	public String getXMLBids(String itemId,int Number_of_Bids) 
	{
		Connection conn = null;
		String result = "";
		try {
			conn = DbManager.getConnection(true);
			Statement stmt = conn.createStatement();
			if (Number_of_Bids > 0) 
			{
				result += "  <Bids>\n";
				String query = "SELECT * FROM Bid WHERE ItemID = " + itemId+" ORDER BY Time ";
				ResultSet RS_Bid = stmt.executeQuery(query);
				while (RS_Bid.next()) 
				{
					String Bidder_UserID = RS_Bid.getString("Bidder_UserID");
					result += "    <Bid>\n";
					result += getXMLBidder(Bidder_UserID);		
					String sqlDateString = RS_Bid.getString("Time");
					result += "      <Time>" + getXMLDate(sqlDateString) + "</Time>\n";
					result += String.format("      <Amount>$%.2f</Amount>\n", RS_Bid.getDouble("Amount"));
					result += "    </Bid>\n";
				}
				result += "  </Bids>\n";
			} 
			else //Number_of_Bids == 0 
			{
				result += "  <Bids />\n";
			}
			conn.close();
		} 
		catch (Exception ex) 
		{
			System.out.println(ex);
		}
		return result;
	}
	public String getXMLBidder(String Bidder_UserID)
	{
		Connection conn = null;
		String result = "";
		try {
			conn = DbManager.getConnection(true);
			Statement stmt = conn.createStatement();
			String query = "SELECT * FROM Bidder WHERE Bidder_UserID = '" + Bidder_UserID+"' ";// pay attention to use ' ' to include String 
			ResultSet RS_Bidder = stmt.executeQuery(query);

			while (RS_Bidder.next()) // Can be changed to RS_Bidder.first();
			{
				
				//result += "      <Bidder>\n";
				result += "      <Bidder rating=\"" + RS_Bidder.getInt("Bidder_Rating") + "\" UserID=\"" + getStringAfterEscape(RS_Bidder.getString("Bidder_UserID"))+ "\">\n";			
				result += "        <Location>" + getStringAfterEscape(RS_Bidder.getString("Bidder_Location")) + "</Location>\n";
				result += "        <Country>" + getStringAfterEscape(RS_Bidder.getString("Bidder_Country")) + "</Country>\n";
				result += "      </Bidder>\n";
			}
				//result += "</Bids>\n";
			
			conn.close();
		} 
		catch (Exception ex) 
		{
			System.out.println(ex);
		}
		return result;
	}
	public String getXMLDate(String sqlDateString)//2001-01-17
	{
		String finalString="";
		try
		{
		DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.ENGLISH); 
		Date date = (Date)formatter.parse(sqlDateString);
		SimpleDateFormat newFormat = new SimpleDateFormat("MMM-dd-yy HH:mm:ss",Locale.ENGLISH);//Dec-17-01
		finalString = newFormat.format(date);
		//System.out.println("@debug date:"+date);
		}
		catch(Exception ex)
		{
			System.out.println(ex);
		}
		return finalString;
	}
	public String getStringAfterEscape(String input)
	{
		//String output="";
		input=input.replace("&", "&amp;");
		input=input.replace("<", "&lt;");
		input=input.replace(">", "&gt;");
		//input=input.replace("'", "&apos;");
		//input=input.replace("\"", "&quot;");
		//input=input.replace("`", "\"");//special in my program
		return input;
	}

	public String getXMLCategory(String itemId) 
	{
		Connection conn = null;
		String result = "";
		try {
			conn = DbManager.getConnection(true);
			Statement stmt = conn.createStatement();
			String query = "SELECT Category FROM ItemCategory WHERE ItemID = " + itemId;
			ResultSet RS_ItemCategory = stmt.executeQuery(query);
			while (RS_ItemCategory.next()) 
			{
				String Category = RS_ItemCategory.getString("Category");
				
				Category=getStringAfterEscape(Category);
				
				//System.out.println("@debug: "+Category);
				result += "  <Category>" + Category + "</Category>\n";
			}
			conn.close();
		} catch (Exception ex) 
		{
			System.out.println(ex);
		}
		return result;
	}
	public String getXMLCurrently(double Currently) 
	{
		String result = String.format("  <Currently>$%.2f</Currently>\n", Currently);
		return result;
	}
	
	public String getXMLBuyPrice(double Buy_Price) 
	{
		if (Buy_Price == 0) 
		{
			return "";
		}
		String result = String.format("  <Buy_Price>$%.2f</Buy_Price>\n", Buy_Price);
		return result;
	}
	public String getXMLFirstBid(double First_Bid) 
	{
		String result = String.format("  <First_Bid>$%.2f</First_Bid>\n", First_Bid);
		return result;
	}
	public String getXMLNumberOfBids(int Number_of_Bids) 
	{
		String result = "  <Number_of_Bids>" + Number_of_Bids + "</Number_of_Bids>\n";
		return result;
	}
	
	public String echo(String message) {
		return message;
	}

}
